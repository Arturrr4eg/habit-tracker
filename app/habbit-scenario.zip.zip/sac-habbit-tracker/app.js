module.exports = async function ({ req, res, handler }) {
  const command = req.body.request.command.toLowerCase();

  if (command.includes('добавь привычку')) {
    const title = command.replace('добавь привычку', '').trim();

    res.setPronounceText(`Добавляю привычку ${title}`);
    res.setSmartAppData({
      type: 'ADD_HABIT',
      payload: {
        title: title || 'Новая привычка',
        goal: 'Без цели',
        duration: 21,
        startTime: '08:00',
        endTime: '20:00',
        icon: '🔥',
      },
    });
    return handler();
  }

  if (command.includes('покажи список привычек') || command.includes('какие привычки')) {
    res.setPronounceText(`Вот список твоих привычек`);
    res.setSmartAppData({
      type: 'SHOW_HABITS',
    });
    return handler();
  }

  res.setPronounceText('Я не понял команду. Скажи, например, "добавь привычку медитация"');
  handler();
};
