module.exports = {
  addHabit: async ({ req, res, vars }) => {
    const { habitName } = vars;

    res.setPronounceText(`Добавляю привычку ${habitName}`);
    res.setSmartAppData({
      type: 'ADD_HABIT',
      payload: {
        title: habitName || 'Новая привычка',
        goal: 'По умолчанию',
        duration: 21,
        startTime: '08:00',
        endTime: '20:00',
        icon: '💪'
      }
    });
  }
};
